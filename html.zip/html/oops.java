class main{
    public ststic void main(string[] args){
        system.out.println("hello world");
    }
}