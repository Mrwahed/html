
    class student {
    private int roll;
    private String name;
    private String email;
    
    public int getRoll() {
        return roll;
     
    }
    public void setRoll(int roll) {
        this.roll = roll;
    }
    
    public String getName(){
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email){
        this.email = email;
    }
}
   public class studentTest{
       public static void main(String[] args){
           student student = new Student(); 
           student.setRoll(101);
           student.setName("Wahed");
           student.setEmail("wahed143@gmail.com");
           System.out.println(student.getRoll()+""+student.getName()+""+student.getEmail());
       }
   }