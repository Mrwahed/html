
public class mystack {

    int[] data = new int[5];
    int top;

    mystack() {
        this.top = -1;
    }

    boolean isEmpty() {
        if (top < 0) {
            System.out.println("Stack is Empty!");
            return true;
        }
        return false;
    }

    boolean push(int element) {
        if (top >= (data.length - 1)) {
            System.out.println("Stack Overflow!");
            return false;
        } else {
            data[++top] = element;
            System.out.println(element + " inserted at " + top);
            return true;
        }
    }

    int pop() {
        if (top < 0) {
            System.out.println("Stack Underflow!");
            return 0;
        } else {
            int element = data[top];
            System.out.println(element + " was deleted from " + top);
            top--;
            return element;
        }
    }

    int peek() {
        if (top < 0) {
            System.out.println("Stack Underflow!");
            return 0;
        } else {
            int element = data[top];
            System.out.println(element + " at position " + top);
            return element;
        }
    }

    public static void main(String[] args) {
        mystack myStack = new mystack();
        // myStack.isEmpty();

        myStack.push(10);
        myStack.push(20);
        myStack.push(30);
        myStack.push(40);
        myStack.push(50);

        myStack.peek();

        // myStack.pop();
        // myStack.pop();
        // myStack.pop();
        // myStack.pop();
        // myStack.pop();
        //  myStack.pop();

    }
}
